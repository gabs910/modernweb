

function displayName(name) {
    console.log('Hello, ' + name)
}

displayName("Gabriel");