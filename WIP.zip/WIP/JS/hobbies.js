const hobbiesArray = [
    { name: 'reading', lengthInYearsAtHobby: 30  },
    { name: 'playing guitar', lengthInYearsAtHobby: 5},
    { name: 'sports', lengthInYearsAtHobby: 20}
];


function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} enjoyed for ${hobby.lengthInYearsAtHobby} `)
}

for(let x=0; x < hobbiesArray.length; x++) {
    printHobbyInfo(hobbiesArray[x]);
}