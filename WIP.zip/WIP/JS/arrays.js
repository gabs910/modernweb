let Hobbies = ['reading', 'playing guitar', 'sports'];

function printHobbies(passedArray) {
    console.log(`I like ${passedArray.length} things`);
    for (let index = 0; index < Hobbies.length; index++) {
        let element = Hobbies[index];
        console.log('I like ' + element);
    }
}
printHobbies(Hobbies);