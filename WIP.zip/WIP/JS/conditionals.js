let numOne = 1;
let stringOne = '1';


console.log('double ==', numOne == stringOne);
console.log('triple ===', numOne === stringOne);